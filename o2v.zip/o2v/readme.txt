OBJ2VERTIGO v0.0.3          10/11/2000
(c)Gregor Rozman, All rights reserved.
--------------------------------------

::Info()
{
	This is just a first try to make some documentation for
	O2V, so please bear with me :)
	
	What is this O2V anyway? O2V was created especially for
	Vertigo flight sim, and allow us to add our 3d objects
	much easier than it used to be, using Wavefront .OBJ as a
	base file format and converting it to the Vertigo native
	format.
	Note though that O2V is far from being complete so do not
	expect from it any wonders ;)
	
	Oh yeah, almost forgot... O2V is a freeware.
}

::Installation()
{
	To install O2V simply extract zip file and you are
	ready to go.
}

::Useage()
{
	O2V is a command line utility.
	To use it, simply follow the following example:
		o2v cube cube.obj
	This will convert CUBE.OBJ file to the Vertigo's .C format
	
	NOTE: There are some limitations with O2V and its grammar
	for parsing .OBJ format.
	
		Notes on .OBJ parser limitations:
		(1) -	The face 'f' must have ONLY 3 indices!
			f 32 44 33
		(2) -	Parser can ignore only following macros:
			"#", "usemtl" and "mtllib"
			Any other may result in errors of program!
			
		O2V general:
		(1) - 	At this moment O2V can only convert to the
			static mesh. So no control surfaces which
			are used in Vertigo can be set with O2V.
			To set control surfaces you can still
			convert using O2V, but you must the edit the
			Vertigo file according to its 'SDK' readme.
			Also to set anything else, like draw_dist
			variables in Vertigo format, you must edit
			that manually with editing Vertigo's .C file.
			For more info on Vertigo's file format,
			please read the included docs with Vertigo.
		(2) -	__ADD_HERE__
}

::Contact()
{
	Please send any suggestions and bugs to:
		gregor.rozman@promi.si
}
